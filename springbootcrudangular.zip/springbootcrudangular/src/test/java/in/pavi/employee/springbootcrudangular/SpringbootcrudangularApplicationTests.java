package in.pavi.employee.springbootcrudangular;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootcrudangularApplicationTests {

	@Test
	void contextLoads() {
	}

}
