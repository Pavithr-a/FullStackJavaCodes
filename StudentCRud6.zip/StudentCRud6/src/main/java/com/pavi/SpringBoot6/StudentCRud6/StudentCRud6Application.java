package com.pavi.SpringBoot6.StudentCRud6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentCRud6Application {

	public static void main(String[] args) {
		SpringApplication.run(StudentCRud6Application.class, args);
	}

}
